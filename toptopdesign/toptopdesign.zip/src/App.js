import './App.css';
import Routers from './router';

function App() {
  return (
    <>
      <Routers />
    </>
  );
}

export default App;
