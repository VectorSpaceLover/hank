import styled from 'styled-components';
import {
    PptelegrafUltraBoldBlack28px,
  } from '../../../assets/styledMixins';

export const Styles = styled.div`
    .app-list-conatiner{
        .title{
            ${PptelegrafUltraBoldBlack28px}
            min-height: 30px;
            letter-spacing: 0;
            padding: 60px 0px 24px 0px;
        }
        .app-list{
            
        }
    }
`;