import styled from "styled-components";


export const Styles = styled.div`
    .image-container{
        position: relative;
        padding: 10px;
        box-shadow: 4px -2px 9px 8px rgb(0 0 0 / 2%);
        background-color: var(--white);
        border-radius: 16px;
        .image-viewer{
            
        }
        .favourite{
            position: absolute;
            top: 33px;
            right: 18px;
        }
    }
`;