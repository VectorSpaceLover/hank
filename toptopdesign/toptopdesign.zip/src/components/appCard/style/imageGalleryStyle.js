import styled from 'styled-components';


export const Styles = styled.div`
    .gallery{
        background-color: var(--white);
        width: 200px;
        object-fit: cover;
    }
`;