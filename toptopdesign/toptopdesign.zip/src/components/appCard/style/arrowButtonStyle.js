import styled from 'styled-components';

export const Styles = styled.div`
    .icon-arrow{
        
    }
`;