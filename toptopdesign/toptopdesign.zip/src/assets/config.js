
export const navbarData = {
    items: [
        "ITEM",
        "ITEM",
        "ITEM",
        "ITEM",
    ],
    titleImage: "https://anima-uploads.s3.amazonaws.com/projects/621ea468b7b66445f330bb3a/releases/621ea67598af0465c7322215/img/group-564-2@2x.svg",
    signIn: "SIGN IN",
    line38: "https://anima-uploads.s3.amazonaws.com/projects/621ea468b7b66445f330bb3a/releases/621ea5127008b16657f7b4ca/img/line-38@2x.svg",
    line154: "https://anima-uploads.s3.amazonaws.com/projects/621ea468b7b66445f330bb3a/releases/621ea5127008b16657f7b4ca/img/line-154@1x.svg",
};

export const allPatternItems = [
    {
        name: 'All Patterns',
    },
    {
        name: 'Sign In',
    },
    {
        name: 'Sign Up',
    },
    {
        name: 'On Boarding',
    },
    {
        name: 'Sign In',
    },
    {
        name: 'Sign Up',
    },
    {
        name: 'On Boarding',
    },
    {
        name: 'Sign In',
    },
    {
        name: 'Sign Up',
    },
    {
        name: 'On Boarding',
    },
    {
        name: 'Sign In',
    },
    {
        name: 'Sign Up',
    },
    {
        name: 'On Boarding',
    },
    {
        name: 'Sign In',
    },
    {
        name: 'Sign Up',
    },
    {
        name: 'On Boarding',
    },
    {
        name: 'Sign In',
    },
    {
        name: 'Sign Up',
    },
    {
        name: 'On Boarding',
    },
];

export const popularApps = [
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
];

export const addedApps = [
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
];

export const popularWebSites = [
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
    {
        name: 'Name Of the Apple',
        subName: 'App CATEGORY TAG',
        imageList:[
            '',
            '',
            ''
        ]
    },
];

export const messages = [
    {
        title: 'Lorem ipsum dolor sit amet, consectetur...',
        date: '1 days ago',
        messageContent: ''
    },
    {
        title: 'Lorem ipsum dolor sit amet, consectetur...',
        date: '1 days ago',
        messageContent: ''
    },
    {
        title: 'Lorem ipsum dolor sit amet, consectetur...',
        date: '1 days ago',
        messageContent: ''
    },
    {
        title: 'Lorem ipsum dolor sit amet, consectetur...',
        date: '1 days ago',
        messageContent: ''
    },
    {
        title: 'Lorem ipsum dolor sit amet, consectetur...',
        date: '1 days ago',
        messageContent: ''
    },
    {
        title: 'Lorem ipsum dolor sit amet, consectetur...',
        date: '1 days ago',
        messageContent: ''
    },
    {
        title: 'Lorem ipsum dolor sit amet, consectetur...',
        date: '1 days ago',
        messageContent: ''
    },
    {
        title: 'Lorem ipsum dolor sit amet, consectetur...',
        date: '1 days ago',
        messageContent: ''
    },
    {
        title: 'Lorem ipsum dolor sit amet, consectetur...',
        date: '1 days ago',
        messageContent: ''
    },
    {
        title: 'Lorem ipsum dolor sit amet, consectetur...',
        date: '1 days ago',
        messageContent: ''
    },
    {
        title: 'Lorem ipsum dolor sit amet, consectetur...',
        date: '1 days ago',
        messageContent: ''
    },
];

export const keywords = [
    {
        keyword: "Kabul",
    },
    {
        keyword: "Tirane",
    },
    {
        keyword: "Algiers",
    }
  ];
  